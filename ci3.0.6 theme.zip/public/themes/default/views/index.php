<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Wr</title>
 
</head>
<body>

<div id="container">
	<h1>Welcome to Teheme!</h1>
 



	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>

</body>
</html>