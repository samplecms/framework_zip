<?php

use app\controllers\Base;

class Welcome extends Base {
 	 

	public function index()
	{
	
		$this->load->view('index');
	}
}
