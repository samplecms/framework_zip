<?php
namespace app\controllers;
use CI_Controller;
class Base extends CI_Controller {
 	public $theme = 'default';

	public function __construct()
	{
		parent::__construct();

		$this->load->add_package_path(realpath(APPPATH.'../public').'/themes/'.$this->theme);
		 
	}


}
